﻿using AccessControlSystem.Models.Contracts;
using AccessControlSystem.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessControlSystem.Core.Contracts
{
    internal class Controller : IController
    {
        string IController.AddDepartment(string departmentTypeName)
        {
            if (string.IsNullOrWhiteSpace(departmentTypeName))
            {
                throw new ArgumentException("Department type name cannot be null or empty.", nameof(departmentTypeName));
            }

            var type = Type.GetType(departmentTypeName);

            if (type == null || !typeof(Department).IsAssignableFrom(type))
            {
                throw new ArgumentException(
                    string.Format(OutputMessages.InvalidDepartmentType, departmentTypeName),
                    nameof(departmentTypeName)
                );
            }

            return $"{departmentTypeName} is already created.";
        }



        private readonly EmployeeRepository _employeeRepository = new EmployeeRepository();

        public string AddEmployeeToApplication(string employeeName, string employeeTypeName, int securityId)
        {
            if (employeeTypeName == "GeneralEmployee")
            {
                if (_employeeRepository.GetByName(employeeName) != null)
                {
                    return $"{employeeTypeName} is already added to the application.";
                }
                var employee = new GeneralEmployee(employeeName, securityId);
              
                return $"{employeeTypeName} is successfully added to the application.";
            }
            else if (employeeTypeName == "ITSpecialist")
            {
                if (_employeeRepository.GetByName(employeeName) != null)
                {
                    return $"{employeeTypeName} is already added to the application.";
                }

                var employee = new ITSpecialist(employeeName, securityId);
               
                return $"{employeeTypeName} is successfully added to the application.";
            }
            else
            {
                return string.Format("{0} is not a valid employee type.", employeeTypeName);
            }
        }

        string IController.AddEmployeeToDepartment(string employeeName, string departmentTypeName)
        {
            throw new NotImplementedException();
        }

        string IController.AddSecurityZone(string securityZoneName, int accessLevelRequired)
        {
            throw new NotImplementedException();
        }

        string IController.AuthorizeAccess(string securityZoneName, string employeeName)
        {
            throw new NotImplementedException();
        }

        string IController.SecurityReport()
        {
            throw new NotImplementedException();
        }
    }
}
