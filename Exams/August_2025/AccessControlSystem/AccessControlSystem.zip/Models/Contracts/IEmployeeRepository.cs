﻿namespace AccessControlSystem.Models.Contracts
{
    internal interface IEmployeeRepository
    {
    }
}