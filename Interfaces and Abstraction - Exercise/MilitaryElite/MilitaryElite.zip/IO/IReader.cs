﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.IO
{
    public interface IReader
    {
        string Readline();
    }
}
