﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Core.Models.Enums
{
    public enum State
    {
        inProgress,
        Finished
    }
}
