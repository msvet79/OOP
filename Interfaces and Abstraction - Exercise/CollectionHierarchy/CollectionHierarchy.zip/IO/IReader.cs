﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy.IO
{
    public interface IReader
    {
        public string Readline();
    }
}
