﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.IO.Interefaces
{
    public interface IReader
    {
        public string Readline();
    }
}
