﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Exceptions
{
   public static class ExceptionMessages
    {
        public const string InsufficientFuelExceptionMessage = "{0} needs refueling";
    }
}
